import type { Metadata } from "next";
import Link from "next/link";
import Prose from "@/components/Prose";
import { SITE } from "@/lib/site";
export const metadata: Metadata = { title: "About Us", description: "What MoneyWiseHub is, who it is for, and how we approach financial education.", alternates: { canonical: "/about" } };
export default function About() {
  return (
    <Prose title="About Us" updated={false}>
      <p>{SITE.name} is an independent personal finance education website. Our aim is to explain everyday money topics clearly: budgeting, saving, interest, debt, credit and the basics of investing.</p>
      <h2>Who it is for</h2>
      <p>Our readers are mainly in the United States, United Kingdom, Canada and Australia. Money rules differ between these countries, so we label country-specific information and avoid mixing tax rules.</p>
      <h2>What we do and do not do</h2>
      <ul>
        <li>We publish general educational articles with worked examples and sources.</li>
        <li>We do not give personal financial, investment, tax or legal advice.</li>
        <li>We do not guarantee returns or promise outcomes.</li>
      </ul>
      <h2>How we work</h2>
      <p>Read our <Link href="/editorial-policy">Editorial Policy</Link> for how content is written, sourced and corrected, and our <Link href="/disclaimer">Disclaimer</Link> for the limits of what we publish. Questions or corrections are welcome through the <Link href="/contact">contact page</Link>.</p>
    </Prose>
  );
}
