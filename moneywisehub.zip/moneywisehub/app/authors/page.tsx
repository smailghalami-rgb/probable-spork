import type { Metadata } from "next";
import Link from "next/link";
import Prose from "@/components/Prose";
import { SITE } from "@/lib/site";
export const metadata: Metadata = { title: "Authors & Contributors", description: "Who writes MoneyWiseHub content and what that means for how you should use it.", alternates: { canonical: "/authors" } };
export default function Authors() {
  return (
    <Prose title="Authors & Contributors" updated={false}>
      <h2>{SITE.author}</h2>
      <p>Articles on this site are published under the {SITE.author}. We do not claim professional financial qualifications for our writers, and our content should not be treated as advice from a regulated adviser.</p>
      <p>See how we write and check content in our <Link href="/editorial-policy">Editorial Policy</Link>.</p>
    </Prose>
  );
}
