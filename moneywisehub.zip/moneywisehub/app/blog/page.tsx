import Link from "next/link";
import type { Metadata } from "next";
import { ARTICLES } from "@/lib/articles";
import Breadcrumbs from "@/components/Breadcrumbs";

export const metadata: Metadata = {
  title: "Personal Finance Articles",
  description: "Educational guides on budgeting, saving, emergency funds and compound interest.",
  alternates: { canonical: "/blog" },
};

export default function Blog() {
  return (
    <>
      <Breadcrumbs items={[{ name: "Home", href: "/" }, { name: "Articles" }]} />
      <h1 className="text-3xl font-bold text-slate-900">Personal Finance Articles</h1>
      <ul className="mt-6 space-y-5">
        {ARTICLES.map((a) => (
          <li key={a.slug} className="rounded-xl border border-slate-200 p-5">
            <p className="text-xs font-semibold uppercase text-brand">{a.category} · {a.readMinutes} min read</p>
            <h2 className="mt-1 text-xl font-semibold"><Link href={`/blog/${a.slug}`} className="hover:text-brand">{a.title}</Link></h2>
            <p className="mt-2 text-slate-600">{a.description}</p>
          </li>
        ))}
      </ul>
    </>
  );
}
