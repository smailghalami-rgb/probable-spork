import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { ARTICLES, getArticle } from "@/lib/articles";
import { ARTICLE_CALCS, getCalc } from "@/lib/calculators";
import { SITE } from "@/lib/site";
import Breadcrumbs from "@/components/Breadcrumbs";
import AdSlot from "@/components/AdSlot";

type Props = { params: Promise<{ slug: string }> };

export function generateStaticParams() {
  return ARTICLES.map((a) => ({ slug: a.slug }));
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const a = getArticle((await params).slug);
  if (!a) return {};
  const url = `/blog/${a.slug}`;
  return {
    title: a.title,
    description: a.description,
    alternates: { canonical: url },
    openGraph: { title: a.title, description: a.description, url, type: "article", publishedTime: a.published, modifiedTime: a.updated },
  };
}

export default async function ArticlePage({ params }: Props) {
  const a = getArticle((await params).slug);
  if (!a) notFound();
  const related = a.related.map(getArticle).filter((x): x is NonNullable<typeof x> => !!x);

  const calcs = (ARTICLE_CALCS[a.slug] ?? []).map(getCalc).filter((x): x is NonNullable<typeof x> => !!x);
  const jsonLd = [
    {
      "@context": "https://schema.org", "@type": "Article", headline: a.title, description: a.description,
      datePublished: a.published, dateModified: a.updated,
      author: { "@type": "Organization", name: SITE.author },
      publisher: { "@type": "Organization", name: SITE.name },
      mainEntityOfPage: `${SITE.url}/blog/${a.slug}`,
    },
    {
      "@context": "https://schema.org", "@type": "FAQPage",
      mainEntity: a.faqs.map((f) => ({ "@type": "Question", name: f.q, acceptedAnswer: { "@type": "Answer", text: f.a } })),
    },
  ];

  return (
    <article className="mx-auto max-w-3xl">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      <Breadcrumbs items={[{ name: "Home", href: "/" }, { name: "Articles", href: "/blog" }, { name: a.title }]} />
      <h1 className="text-3xl font-bold text-slate-900 sm:text-4xl">{a.title}</h1>
      <p className="mt-3 text-sm text-slate-500">
        By {SITE.author} · Published {a.published} · Updated {a.updated} · {a.readMinutes} min read
      </p>
      <p className="mt-6 text-lg text-slate-700">{a.intro}</p>
      <AdSlot />
      {a.sections.map((s) => (
        <section key={s.h}>
          <h2 className="mt-10 text-2xl font-bold text-slate-900">{s.h}</h2>
          {s.p.map((t) => <p key={t} className="mt-4 leading-relaxed">{t}</p>)}
          {s.list && (
            <ul className="mt-4 list-disc space-y-2 pl-6">{s.list.map((li) => <li key={li}>{li}</li>)}</ul>
          )}
        </section>
      ))}
      <h2 className="mt-10 text-2xl font-bold text-slate-900">Frequently asked questions</h2>
      {a.faqs.map((f) => (
        <div key={f.q} className="mt-4">
          <h3 className="font-semibold text-slate-900">{f.q}</h3>
          <p className="mt-1">{f.a}</p>
        </div>
      ))}
      <p className="mt-10 rounded-lg bg-slate-50 p-4 text-sm text-slate-600">
        This article is general education, not personal financial advice. Figures are illustrative examples, and rules and rates differ by country.{" "}
        <Link href="/disclaimer" className="text-brand underline">Read the full disclaimer</Link>.
      </p>
      {calcs.length > 0 && (<><h2 className="mt-10 text-xl font-bold text-slate-900">Try a calculator</h2><ul className="mt-3 list-disc pl-6">{calcs.map((c) => <li key={c.slug}><Link href={`/calculators/${c.slug}`} className="text-brand underline">{c.title}</Link></li>)}</ul></>)}
      <h2 className="mt-10 text-xl font-bold text-slate-900">Related articles</h2>
      <ul className="mt-3 list-disc pl-6">
        {related.map((r) => <li key={r.slug}><Link href={`/blog/${r.slug}`} className="text-brand underline">{r.title}</Link></li>)}
      </ul>
      <h2 className="mt-10 text-xl font-bold text-slate-900">Sources and further reading</h2>
      <ul className="mt-3 list-disc pl-6 text-sm">
        {a.references.map((r) => (
          <li key={r.url}><a href={r.url} rel="noopener noreferrer" target="_blank" className="text-brand underline">{r.name}</a></li>
        ))}
      </ul>
    </article>
  );
}
