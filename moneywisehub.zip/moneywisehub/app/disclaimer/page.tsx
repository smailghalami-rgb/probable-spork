import type { Metadata } from "next";
import Breadcrumbs from "@/components/Breadcrumbs";
import { SITE } from "@/lib/site";

export const metadata: Metadata = {
  title: "Financial Content Disclaimer",
  description: "MoneyWiseHub provides general financial education only, not financial, tax, investment or legal advice.",
  alternates: { canonical: "/disclaimer" },
};

export default function Disclaimer() {
  return (
    <div className="mx-auto max-w-3xl">
      <Breadcrumbs items={[{ name: "Home", href: "/" }, { name: "Financial Content Disclaimer" }]} />
      <h1 className="text-3xl font-bold text-slate-900">Financial Content Disclaimer</h1>
      <div className="mt-6 space-y-4 leading-relaxed">
        <p>{SITE.name} publishes general educational content about personal finance. It is not financial, investment, tax, accounting or legal advice, and it does not take your personal circumstances into account.</p>
        <p>Nothing on this site guarantees any outcome or return. All investing involves risk, including the possible loss of money, and past performance does not predict future results. Examples use illustrative numbers only.</p>
        <p>Rules, taxes, products and rates differ between countries and change over time. Where an article is specific to one country, it says so. Please check current rules with official sources.</p>
        <p>Before making financial decisions, consider speaking with a suitably qualified professional who can look at your situation. Use of this site does not create any professional or advisory relationship.</p>
      </div>
    </div>
  );
}
