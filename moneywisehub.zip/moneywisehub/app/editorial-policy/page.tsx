import type { Metadata } from "next";
import Link from "next/link";
import Prose from "@/components/Prose";
export const metadata: Metadata = { title: "Editorial Policy", description: "How MoneyWiseHub researches, writes, reviews and corrects its financial education content.", alternates: { canonical: "/editorial-policy" } };
export default function Editorial() {
  return (
    <Prose title="Editorial Policy">
      <h2>Purpose</h2>
      <p>Our content exists to help readers understand money concepts. It is educational, not advice, and we aim to be clear about risk and uncertainty.</p>
      <h2>Standards</h2>
      <ul>
        <li>Content is written originally for this site, not copied from other sources.</li>
        <li>Factual claims about rules, products or tax are checked against official or reputable sources, which are listed at the end of each article.</li>
        <li>Country-specific information is labelled, and we do not mix tax rules from different countries.</li>
        <li>We do not guarantee returns, promise wealth, or recommend specific investments to individuals.</li>
        <li>Examples use illustrative numbers and say so.</li>
      </ul>
      <h2>Independence and advertising</h2>
      <p>Advertising, if shown, is clearly separate from editorial content and does not decide what we write. We do not publish fake reviews or testimonials.</p>
      <h2>Updates and corrections</h2>
      <p>Articles show published and updated dates. Rules and rates change, so we revise articles when we find them out of date. To report an error, use the <Link href="/contact">contact page</Link>.</p>
    </Prose>
  );
}
