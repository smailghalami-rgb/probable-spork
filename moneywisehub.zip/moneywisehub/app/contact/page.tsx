import type { Metadata } from "next";
import Prose from "@/components/Prose";
import ContactForm from "@/components/ContactForm";
export const metadata: Metadata = { title: "Contact Us", description: "Send a question, correction or privacy request to the MoneyWiseHub team.", alternates: { canonical: "/contact" } };
export default function Contact() {
  return (
    <Prose title="Contact Us" updated={false}>
      <p>Use this form for questions, corrections or privacy requests. We cannot give personal financial advice.</p>
      <ContactForm />
    </Prose>
  );
}
