import type { Metadata } from "next";
import Link from "next/link";
import Prose from "@/components/Prose";
import { SITE } from "@/lib/site";
export const metadata: Metadata = { title: "Cookie Policy", description: "What cookies MoneyWiseHub uses and how you can control them.", alternates: { canonical: "/cookie-policy" } };
export default function Cookies() {
  return (
    <Prose title="Cookie Policy">
      <p>Cookies are small files stored on your device. This page explains how {SITE.name} uses them.</p>
      <h2>Current use</h2>
      <p>At the time of writing, this site does not set analytics or advertising cookies. Our hosting may use strictly necessary technical measures to deliver and secure the site.</p>
      <h2>If advertising is enabled</h2>
      <p>If we enable Google AdSense, Google and its partners may set cookies to serve and measure ads. Where the law requires it (for example in the UK and EU), we will show a consent notice and only set non-essential cookies after you agree, and we will update this page to list them.</p>
      <h2>Your choices</h2>
      <ul>
        <li>Use your browser settings to block or delete cookies. Some site features may be affected.</li>
        <li>Use the consent controls on this site when they are available.</li>
      </ul>
      <p>For more on how we handle data, see our <Link href="/privacy-policy">Privacy Policy</Link>.</p>
    </Prose>
  );
}
