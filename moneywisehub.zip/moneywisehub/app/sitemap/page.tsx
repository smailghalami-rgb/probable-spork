import type { Metadata } from "next";
import Link from "next/link";
import Prose from "@/components/Prose";
import { CALCS } from "@/lib/calculators";
import { ARTICLES } from "@/lib/articles";
export const metadata: Metadata = { title: "Sitemap", description: "A list of all pages and articles on MoneyWiseHub.", alternates: { canonical: "/sitemap" } };
const PAGES: [string, string][] = [["/", "Home"], ["/blog", "Articles"], ["/calculators", "Calculators"], ["/about", "About Us"], ["/authors", "Authors & Contributors"], ["/editorial-policy", "Editorial Policy"], ["/contact", "Contact Us"], ["/privacy-policy", "Privacy Policy"], ["/terms", "Terms & Conditions"], ["/cookie-policy", "Cookie Policy"], ["/disclaimer", "Financial Content Disclaimer"]];
export default function SitemapPage() {
  return (
    <Prose title="Sitemap" updated={false}>
      <h2>Pages</h2>
      <ul>{PAGES.map(([h, n]) => <li key={h}><Link href={h}>{n}</Link></li>)}</ul>
      <h2>Calculators</h2>
      <ul>{CALCS.map((c) => <li key={c.slug}><Link href={`/calculators/${c.slug}`}>{c.title}</Link></li>)}</ul>
      <h2>Articles</h2>
      <ul>{ARTICLES.map((a) => <li key={a.slug}><Link href={`/blog/${a.slug}`}>{a.title}</Link></li>)}</ul>
    </Prose>
  );
}
