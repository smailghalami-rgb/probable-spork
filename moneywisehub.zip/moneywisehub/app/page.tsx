import Link from "next/link";
import { ARTICLES } from "@/lib/articles";
import { SITE } from "@/lib/site";

export const metadata = { alternates: { canonical: "/" } };

export default function Home() {
  return (
    <>
      <section className="rounded-2xl bg-brand-soft px-6 py-12 text-center">
        <h1 className="text-3xl font-bold text-slate-900 sm:text-4xl">{SITE.name}</h1>
        <p className="mt-2 text-lg text-brand-dark">{SITE.tagline}</p>
        <p className="mx-auto mt-4 max-w-2xl text-slate-600">
          Plain-English guides to budgeting, saving and how interest works. Educational content only, not personal financial advice.
        </p>
        <Link href="/blog" className="mt-6 inline-block rounded-lg bg-brand px-5 py-3 font-semibold text-white hover:bg-brand-dark">
          Browse articles
        </Link>
        <Link href="/calculators" className="mt-6 ml-3 inline-block rounded-lg border border-brand px-5 py-3 font-semibold text-brand hover:bg-white">
          Try the calculators
        </Link>
      </section>
      <section className="mt-12">
        <h2 className="text-2xl font-bold text-slate-900">Start here</h2>
        <ul className="mt-4 grid gap-4 sm:grid-cols-2">
          {ARTICLES.map((a) => (
            <li key={a.slug} className="rounded-xl border border-slate-200 p-5 hover:border-brand">
              <p className="text-xs font-semibold uppercase text-brand">{a.category}</p>
              <h3 className="mt-1 text-lg font-semibold"><Link href={`/blog/${a.slug}`}>{a.title}</Link></h3>
              <p className="mt-2 text-sm text-slate-600">{a.description}</p>
            </li>
          ))}
        </ul>
      </section>
    </>
  );
}
