import type { Metadata } from "next";
import Link from "next/link";
import Prose from "@/components/Prose";
import { SITE } from "@/lib/site";
export const metadata: Metadata = { title: "Terms & Conditions", description: "The terms for using MoneyWiseHub.", alternates: { canonical: "/terms" } };
export default function Terms() {
  return (
    <Prose title="Terms & Conditions">
      <p>By using {SITE.name} you agree to these terms. If you do not agree, please do not use the site.</p>
      <h2>Educational use only</h2>
      <p>Content is general information, not financial, investment, tax or legal advice. Read our <Link href="/disclaimer">Disclaimer</Link>. You are responsible for your own decisions.</p>
      <h2>No guarantees</h2>
      <p>We try to keep content accurate and current but do not guarantee it is complete, error-free or up to date. Examples and tool results are illustrations, not predictions.</p>
      <h2>Intellectual property</h2>
      <p>Site content is owned by {SITE.operator} unless stated otherwise. You may read and share links to it, but you may not copy or republish substantial parts without permission.</p>
      <h2>Acceptable use</h2>
      <p>Do not misuse the site, attempt to disrupt or gain unauthorised access to it, or use automated tools to overload it.</p>
      <h2>Third-party links and ads</h2>
      <p>We link to external sites and may show third-party ads. We do not control and are not responsible for their content or practices.</p>
      <h2>Limitation of liability</h2>
      <p>To the extent permitted by law, we are not liable for losses arising from your use of or reliance on the site. Nothing here limits liability that cannot be limited by law.</p>
      <h2>Changes and contact</h2>
      <p>We may update these terms and will change the date above. Questions can be sent via the <Link href="/contact">contact page</Link>.</p>
    </Prose>
  );
}
