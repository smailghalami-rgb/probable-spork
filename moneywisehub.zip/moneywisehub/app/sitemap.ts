import type { MetadataRoute } from "next";
import { ARTICLES } from "@/lib/articles";
import { CALCS } from "@/lib/calculators";
import { SITE } from "@/lib/site";
export default function sitemap(): MetadataRoute.Sitemap {
  const paths = ["", "/blog", "/calculators", "/about", "/authors", "/editorial-policy", "/contact", "/privacy-policy", "/terms", "/cookie-policy", "/disclaimer", "/sitemap"];
  const pages = paths.map((p) => ({ url: `${SITE.url}${p}`, lastModified: new Date("2026-11-18") }));
  const posts = ARTICLES.map((a) => ({ url: `${SITE.url}/blog/${a.slug}`, lastModified: new Date(a.updated) }));
  const calcs = CALCS.map((c) => ({ url: `${SITE.url}/calculators/${c.slug}`, lastModified: new Date("2026-11-18") }));
  return [...pages, ...calcs, ...posts];
}
