import type { Metadata } from "next";
import Link from "next/link";
import Prose from "@/components/Prose";
import { SITE } from "@/lib/site";
export const metadata: Metadata = { title: "Privacy Policy", description: "How MoneyWiseHub collects, uses and protects personal information.", alternates: { canonical: "/privacy-policy" } };
export default function Privacy() {
  return (
    <Prose title="Privacy Policy">
      <p>This policy explains what personal information {SITE.name} handles and why. It is operated by {SITE.operator}.{SITE.contactEmail && <> Contact: <a href={`mailto:${SITE.contactEmail}`}>{SITE.contactEmail}</a>.</>}</p>
      <h2>Information we collect</h2>
      <ul>
        <li><strong>Contact form:</strong> your name, email address and message, which you provide when you write to us. We use them only to reply to you.</li>
        <li><strong>Technical data:</strong> our hosting provider (Vercel) may process standard server data such as IP address, browser type and requested pages to deliver the site and keep it secure.</li>
        <li><strong>Calculator inputs:</strong> any tools we add run in your browser, and we do not intend to store the numbers you enter.</li>
      </ul>
      <h2>Advertising and cookies</h2>
      <p>If we show ads through Google AdSense, Google and its partners may use cookies or similar technologies to serve and measure ads, including personalised ads where permitted. Where required, we will ask for your consent first. See our <Link href="/cookie-policy">Cookie Policy</Link>. You can learn how Google uses data from sites that use its services, and manage ad settings, through Google&apos;s own privacy and ad settings pages.</p>
      <h2>How we use information</h2>
      <p>To respond to enquiries, operate and secure the site, and, where enabled, show advertising. We do not sell your personal information.</p>
      <h2>Retention</h2>
      <p>We keep contact messages only as long as needed to respond and for reasonable record-keeping, then delete them.</p>
      <h2>Your rights</h2>
      <p>Depending on where you live (for example the UK, EU, Canada, Australia or some US states), you may have rights to access, correct or delete your personal information, or to object to certain processing. To make a request, use the <Link href="/contact">contact page</Link>.</p>
      <h2>Children</h2>
      <p>This site is not directed at children under 13, and we do not knowingly collect their personal information.</p>
      <h2>Changes</h2>
      <p>We may update this policy and will change the date above when we do.</p>
    </Prose>
  );
}
