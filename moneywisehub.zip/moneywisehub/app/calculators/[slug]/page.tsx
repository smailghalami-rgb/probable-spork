import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { CALCS, getCalc } from "@/lib/calculators";
import { ARTICLES } from "@/lib/articles";
import { ARTICLE_CALCS } from "@/lib/calculators";
import Breadcrumbs from "@/components/Breadcrumbs";
import CalculatorUI from "@/components/CalculatorUI";
import AdSlot from "@/components/AdSlot";

type Props = { params: Promise<{ slug: string }> };
export const generateStaticParams = () => CALCS.map((c) => ({ slug: c.slug }));
export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const c = getCalc((await params).slug);
  if (!c) return {};
  return { title: c.title, description: c.description, alternates: { canonical: `/calculators/${c.slug}` }, openGraph: { title: c.title, description: c.description, url: `/calculators/${c.slug}` } };
}
export default async function CalcPage({ params }: Props) {
  const c = getCalc((await params).slug);
  if (!c) notFound();
  const faqs = [...c.faqs, { q: "Is this financial advice?", a: "No. This calculator is an educational estimate based on the inputs you enter and the assumptions above. It does not account for your full circumstances." }];
  const articles = ARTICLES.filter((a) => (ARTICLE_CALCS[a.slug] ?? []).includes(c.slug));
  const ld = { "@context": "https://schema.org", "@type": "FAQPage", mainEntity: faqs.map((f) => ({ "@type": "Question", name: f.q, acceptedAnswer: { "@type": "Answer", text: f.a } })) };
  const h2 = "mt-10 text-2xl font-bold text-slate-900";
  return (
    <div className="mx-auto max-w-3xl">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(ld) }} />
      <Breadcrumbs items={[{ name: "Home", href: "/" }, { name: "Calculators", href: "/calculators" }, { name: c.title }]} />
      <h1 className="text-3xl font-bold text-slate-900">{c.title}</h1>
      <p className="mt-2 mb-6 text-slate-600">{c.description}</p>
      <CalculatorUI slug={c.slug} />
      <AdSlot />
      <h2 className={h2}>How it is calculated</h2>
      <p className="mt-3 leading-relaxed">{c.method}</p>
      <h2 className={h2}>Example</h2>
      <p className="mt-3 leading-relaxed">{c.example}</p>
      <h2 className={h2}>Assumptions and limitations</h2>
      <p className="mt-3 leading-relaxed">{c.assumptions} Results are estimates for education, not advice or a quote. See our <Link href="/disclaimer" className="text-brand underline">disclaimer</Link>.</p>
      <h2 className={h2}>FAQs</h2>
      {faqs.map((f) => <div key={f.q} className="mt-4"><h3 className="font-semibold">{f.q}</h3><p className="mt-1">{f.a}</p></div>)}
      {articles.length > 0 && (<><h2 className={h2}>Related articles</h2><ul className="mt-3 list-disc pl-6">{articles.map((a) => <li key={a.slug}><Link href={`/blog/${a.slug}`} className="text-brand underline">{a.title}</Link></li>)}</ul></>)}
    </div>
  );
}
