import Link from "next/link";
import type { Metadata } from "next";
import { CALCS } from "@/lib/calculators";
import Breadcrumbs from "@/components/Breadcrumbs";
export const metadata: Metadata = { title: "Free Financial Calculators", description: "Budget, savings, loan, mortgage, interest, debt, inflation and retirement calculators with clear methods and examples.", alternates: { canonical: "/calculators" } };
export default function Calculators() {
  return (
    <>
      <Breadcrumbs items={[{ name: "Home", href: "/" }, { name: "Calculators" }]} />
      <h1 className="text-3xl font-bold text-slate-900">Financial Calculators</h1>
      <p className="mt-2 text-slate-600">Educational tools that show their method, assumptions and limits. Results are estimates, not advice.</p>
      <ul className="mt-6 grid gap-4 sm:grid-cols-2">
        {CALCS.map((c) => (
          <li key={c.slug} className="rounded-xl border border-slate-200 p-5 hover:border-brand">
            <h2 className="text-lg font-semibold"><Link href={`/calculators/${c.slug}`}>{c.title}</Link></h2>
            <p className="mt-2 text-sm text-slate-600">{c.description}</p>
          </li>
        ))}
      </ul>
    </>
  );
}
