import { BATCH2 } from "./articles-batch2";
export type Article = {
  slug: string; title: string; description: string; category: string;
  published: string; updated: string; readMinutes: number; intro: string;
  sections: { h: string; p: string[]; list?: string[] }[];
  faqs: { q: string; a: string }[];
  related: string[];
  references: { name: string; url: string }[];
};

const D = "2026-11-18";
const REF_US = { name: "Consumer Financial Protection Bureau (US)", url: "https://www.consumerfinance.gov/" };
const REF_UK = { name: "MoneyHelper (UK)", url: "https://www.moneyhelper.org.uk/" };
const REF_CA = { name: "Financial Consumer Agency of Canada", url: "https://www.canada.ca/en/financial-consumer-agency.html" };
const REF_AU = { name: "MoneySmart (Australia)", url: "https://moneysmart.gov.au/" };
const REFS = [REF_US, REF_UK, REF_CA, REF_AU];

const BATCH1: Article[] = [
  {
    slug: "how-to-create-a-monthly-budget",
    title: "How to Create a Monthly Budget",
    description: "A step-by-step guide to building a monthly budget: income, expenses, simple frameworks and how to keep it working.",
    category: "Budgeting & Saving", published: D, updated: D, readMinutes: 6,
    intro: "A budget is a plan for your money before the month starts. It does not need to be restrictive. Its job is to show where your money goes so you can make deliberate choices instead of wondering where it went.",
    sections: [
      { h: "Step 1: Work out your take-home income", p: ["Start with the money that actually lands in your account after tax and deductions. If your income varies, use the lowest typical month as your baseline and treat anything extra as a bonus to allocate later."] },
      { h: "Step 2: List your expenses", p: ["Split spending into two groups. Fixed expenses are roughly the same each month, such as rent or mortgage, insurance and loan payments. Variable expenses change, such as groceries, transport, and entertainment."],
        list: ["Review your last two or three months of bank and card statements.", "Include irregular costs by dividing them by 12 (for example, a £600 annual bill is £50 a month).", "Add a line for saving, so it is planned rather than whatever is left over."] },
      { h: "Step 3: Pick a simple framework", p: ["The 50/30/20 rule is a popular rule of thumb: about 50% of take-home pay to needs, 30% to wants and 20% to saving and extra debt repayment. On $3,000 take-home that is $1,500, $900 and $600. It is a starting point, not a law. In a high-cost area, needs may take more, and you can adjust the split."] },
      { h: "Step 4: Track, review and adjust", p: ["Compare what you planned with what you spent at the end of each month. Large gaps are information, not failure. Adjust the categories, not just your willpower. A budget that never changes probably does not match real life."] },
    ],
    faqs: [
      { q: "What if my expenses are higher than my income?", a: "List every category and look for the largest or most flexible ones first. If essentials alone exceed income, a free, impartial debt or money guidance service in your country can help." },
      { q: "How often should I update my budget?", a: "Review it monthly, and whenever income, rent or major bills change." },
    ],
    related: ["how-to-save-money-simple-ways", "how-much-should-you-save-every-month"],
    references: REFS,
  },
  {
    slug: "how-to-save-money-simple-ways",
    title: "10 Simple Ways to Save Money",
    description: "Ten practical, low-effort ways to spend less and save more, with examples you can adapt to your own situation.",
    category: "Budgeting & Saving", published: D, updated: D, readMinutes: 5,
    intro: "Saving rarely comes from one dramatic change. It usually comes from several small habits that add up. These ten ideas are general suggestions, so pick the ones that fit your life.",
    sections: [
      { h: "Ten ideas to consider", p: ["Not every idea suits every household. Start with one or two and build from there."],
        list: [
          "Pay yourself first: move money to savings on payday, before you can spend it.",
          "Review subscriptions every few months and cancel those you no longer use.",
          "Plan meals and make a shopping list to reduce food waste and impulse buys.",
          "Compare providers for insurance, phone and broadband when contracts end.",
          "Wait 24 hours before non-essential purchases.",
          "Use cash-back or loyalty schemes only for things you would buy anyway.",
          "Pay credit cards in full where possible to avoid interest.",
          "Check bank fees and switch accounts if you are paying for features you do not use.",
          "Cut energy use with simple steps such as lowering thermostat settings slightly.",
          "Set a specific goal, such as an emergency fund, so saving has a purpose.",
        ] },
      { h: "Why small amounts matter", p: ["Saving $50 a week is $2,600 a year before any interest. The exact amount matters less than the habit, which you can increase when your income or costs change."] },
    ],
    faqs: [
      { q: "Where should I keep the money I save?", a: "For short-term goals, many people use an easy-access savings account. Check how deposit protection works in your country, and compare rates and fees." },
      { q: "Is it better to save or pay off debt first?", a: "It depends on interest rates and your circumstances. A small cash buffer helps avoid new borrowing, while high-interest debt costs more over time. A free guidance service can help you weigh this up." },
    ],
    related: ["how-to-create-a-monthly-budget", "what-is-an-emergency-fund"],
    references: REFS,
  },
  {
    slug: "how-much-should-you-save-every-month",
    title: "How Much Should You Save Every Month?",
    description: "Understand common saving rules of thumb, why there is no single right figure, and how to choose an amount that fits your budget.",
    category: "Budgeting & Saving", published: D, updated: D, readMinutes: 5,
    intro: "There is no single correct answer. A common guideline is to save around 20% of take-home pay, but the right amount depends on your income, costs, debts and goals.",
    sections: [
      { h: "A starting point, not a rule", p: ["Under the 50/30/20 framework, about 20% of take-home pay goes to saving and extra debt repayment. On $2,500 a month that is $500. If that is not realistic yet, 5% or 10% ($125 or $250) is still a useful start, and you can raise it over time."] },
      { h: "Factors that change the answer", p: ["Think about what you are saving for and how soon you need it."],
        list: ["Emergency fund: often several months of essential expenses.", "Short-term goals: a holiday or car repair within a year or two.", "Long-term goals: retirement and other goals. Pension and retirement account rules differ by country, so check official guidance for yours.", "High-interest debt: repayments may take priority over extra saving."] },
      { h: "Make it automatic", p: ["Setting up a standing order or automatic transfer on payday makes saving a default. Increase the amount whenever your pay rises, even by a small percentage."] },
    ],
    faqs: [
      { q: "Is 20% too much?", a: "It may be, depending on your costs. A smaller regular amount you can keep up beats a larger one you abandon." },
      { q: "Should I save before I have a budget?", a: "A budget helps you find a realistic amount, but even a small automatic transfer is a good start." },
    ],
    related: ["how-to-create-a-monthly-budget", "what-is-an-emergency-fund"],
    references: REFS,
  },
  {
    slug: "what-is-an-emergency-fund",
    title: "What Is an Emergency Fund?",
    description: "Learn what an emergency fund is, how much people commonly aim for, where to keep it and how to build one gradually.",
    category: "Personal Finance Basics", published: D, updated: D, readMinutes: 6,
    intro: "An emergency fund is money set aside for unexpected costs, such as a car repair, urgent home repair or a gap in income. It helps you avoid borrowing when something goes wrong.",
    sections: [
      { h: "How much is enough?", p: ["A common guideline is three to six months of essential expenses. If your essentials (housing, utilities, food, transport, minimum debt payments) are $2,000 a month, that is $6,000 to $12,000. People with variable income or dependants often aim higher, while a first target of one month is still worthwhile."] },
      { h: "Where to keep it", p: ["The money should be safe and easy to reach, so many people use an easy-access savings account separate from everyday spending. Deposit protection schemes differ by country (for example FDIC in the US, FSCS in the UK, CDIC in Canada and the Financial Claims Scheme in Australia), so check the current limits for your bank."] },
      { h: "How to build one gradually", p: ["Start with a small target, such as one month of essentials, and automate a regular transfer. Add windfalls such as tax refunds or bonuses when you can. Rebuild the fund after you use it."] },
      { h: "What counts as an emergency?", p: ["Unexpected and necessary costs qualify. Planned or optional spending does not, and sinking funds for predictable costs, like annual insurance, keep your emergency fund intact."] },
    ],
    faqs: [
      { q: "Should I invest my emergency fund?", a: "Investments can fall in value, and an emergency fund is meant to be available when needed, so many people keep it in cash savings. This is general education, so consider your own situation." },
      { q: "Should I build it before paying off debt?", a: "Many people build a small starter buffer first to avoid new borrowing, then balance further saving and repayment. The best split depends on your interest rates." },
    ],
    related: ["how-much-should-you-save-every-month", "how-to-save-money-simple-ways"],
    references: REFS,
  },
  {
    slug: "how-compound-interest-works",
    title: "How Compound Interest Works",
    description: "A clear explanation of compound interest, the formula, a worked example and the limits of projections.",
    category: "Banking & Interest", published: D, updated: D, readMinutes: 6,
    intro: "Compound interest means you earn interest on your original money and on the interest already added. Over longer periods this can make a noticeable difference, in savings and in debt.",
    sections: [
      { h: "The formula", p: ["A = P(1 + r/n)^(nt), where P is the starting amount, r is the annual rate as a decimal, n is the number of compounding periods per year and t is the number of years."] },
      { h: "A worked example", p: ["Put $1,000 in an account paying 5% a year, compounded annually, for 10 years. A = 1,000 × 1.05^10 = about $1,628.89. With simple interest, which is only paid on the original $1,000, you would have $1,500. The $128.89 difference is interest earned on interest."] },
      { h: "What changes the result", p: ["Three things matter most."],
        list: ["Time: the longer money stays, the more compounding matters.", "Rate: higher rates grow faster, but variable rates can change.", "Frequency: more frequent compounding, such as monthly rather than yearly, gives a slightly higher result at the same stated rate."] },
      { h: "It works against borrowers too", p: ["Credit card and other debt can also compound, so unpaid balances can grow quickly. This is why paying off high-interest debt matters."] },
      { h: "Limits of projections", p: ["The example assumes a fixed rate and no withdrawals, fees, taxes or inflation. Real savings rates change, and investment returns are not guaranteed and can be negative. Treat results as illustrations, not predictions."] },
    ],
    faqs: [
      { q: "What is the difference between simple and compound interest?", a: "Simple interest is paid only on the original amount. Compound interest is paid on the original amount plus earlier interest." },
      { q: "Is compound interest guaranteed?", a: "Only for products with a fixed, contractual rate. Investment returns are uncertain and can be lower than expected or negative." },
    ],
    related: ["what-is-an-emergency-fund", "how-much-should-you-save-every-month"],
    references: REFS,
  },
];

export const ARTICLES: Article[] = [...BATCH1, ...BATCH2];

export const getArticle = (slug: string) => ARTICLES.find((a) => a.slug === slug);
