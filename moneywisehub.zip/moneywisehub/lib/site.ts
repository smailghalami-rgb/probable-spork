export const SITE = {
  name: "MoneyWiseHub",
  tagline: "Understand Money. Build Better Habits.",
  url: process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000",
  author: "MoneyWiseHub Editorial Team",
  // Set these in your environment; nothing is invented here.
  operator: process.env.NEXT_PUBLIC_OPERATOR_NAME ?? "the owner of MoneyWiseHub",
  contactEmail: process.env.NEXT_PUBLIC_CONTACT_EMAIL ?? "",
};
export const UPDATED = "2026-11-18";
