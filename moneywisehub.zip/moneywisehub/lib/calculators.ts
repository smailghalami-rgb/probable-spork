export type Unit = "money" | "%" | "years" | "months" | "hours" | "weeks" | "age" | "";
export type Field = { id: string; label: string; def: number; unit: Unit };
export type Row = { label: string; value: number | string; kind: "money" | "pct" | "num" | "text"; big?: boolean };
type V = Record<string, number>;
export type Calc = {
  slug: string; title: string; description: string; fields: Field[];
  compute: (v: V) => Row[]; method: string; example: string; assumptions: string;
  faqs: { q: string; a: string }[];
};

const m = (label: string, value: number, big = false): Row => ({ label, value, kind: "money", big });
const n = (label: string, value: number): Row => ({ label, value, kind: "num" });
const f = (id: string, label: string, def: number, unit: Unit = "money"): Field => ({ id, label, def, unit });

function pmt(P: number, rate: number, years: number) {
  const i = rate / 1200, k = Math.round(years * 12);
  if (k <= 0) return 0;
  return i === 0 ? P / k : (P * i) / (1 - Math.pow(1 + i, -k));
}
// Balance with deposits at the END of each month; interest compounds `perYear` times a year.
function grow(p0: number, monthly: number, rate: number, years: number, perYear: number) {
  const em = Math.pow(1 + rate / 100 / perYear, perYear / 12) - 1;
  let b = p0;
  for (let k = 0; k < Math.round(years * 12); k++) b = b * (1 + em) + monthly;
  return b;
}
function payoff(B: number, apr: number, P: number) {
  const i = apr / 1200;
  if (B <= 0) return { months: 0, interest: 0 };
  if (P <= B * i) return null;
  let b = B, months = 0, interest = 0;
  while (b > 0.005 && months < 1200) { const it = b * i; interest += it; b = b + it - P; months++; }
  return { months, interest };
}
const payoffRows = (B: number, apr: number, P: number): Row[] => {
  const r = payoff(B, apr, P);
  if (!r) return [{ label: "Result", value: "Never: the payment does not cover the monthly interest", kind: "text", big: true }];
  return [n("Months to pay off", r.months), m("Total interest paid", r.interest, true), m("Total paid", B + r.interest)];
};

export const CALCS: Calc[] = [
  {
    slug: "monthly-budget-calculator", title: "Monthly Budget Calculator",
    description: "Add up your monthly income and spending to see what is left over and your savings rate.",
    fields: [f("income", "Monthly take-home income", 3000), f("housing", "Housing", 1000), f("utilities", "Utilities and bills", 250), f("food", "Food and groceries", 400), f("transport", "Transport", 200), f("debt", "Debt repayments", 150), f("other", "Other spending", 300), f("savings", "Planned savings", 300)],
    compute: (v) => {
      const out = v.housing + v.utilities + v.food + v.transport + v.debt + v.other + v.savings;
      return [m("Total planned outgoings", out), m("Left over each month", v.income - out, true), { label: "Savings rate", value: v.income > 0 ? (v.savings / v.income) * 100 : 0, kind: "pct" }];
    },
    method: "Total outgoings are the sum of all spending categories plus planned savings. Left over = income − outgoings. Savings rate = planned savings ÷ income.",
    example: "With $3,000 income and $2,600 of outgoings including $300 savings, you have $400 left over and a 10% savings rate.",
    assumptions: "Use take-home (after-tax) income and average monthly amounts. A negative left-over figure means planned outgoings exceed income.",
    faqs: [{ q: "Should savings count as spending?", a: "Here savings are treated as planned outgoings so the money is allocated before it is spent elsewhere." }],
  },
  {
    slug: "savings-goal-calculator", title: "Savings Goal Calculator",
    description: "Find the monthly amount needed to reach a savings goal by a target date.",
    fields: [f("goal", "Savings goal", 10000), f("current", "Already saved", 1000), f("months", "Months to reach goal", 24, "months"), f("rate", "Annual interest rate", 3, "%")],
    compute: (v) => {
      const k = Math.round(v.months);
      if (k <= 0) return [{ label: "Result", value: "Enter at least 1 month", kind: "text" }];
      const i = v.rate / 1200, g = Math.pow(1 + i, k);
      const need = v.goal - v.current * g;
      const pay = need <= 0 ? 0 : i === 0 ? need / k : (need * i) / (g - 1);
      return [m("Monthly saving needed", pay, true), m("Total you deposit", pay * k + v.current), m("Interest earned (estimate)", Math.max(0, v.goal - (pay * k + v.current)))];
    },
    method: "Deposits are made at the end of each month and interest compounds monthly. Payment = (Goal − Current × (1+i)^n) × i ÷ ((1+i)^n − 1), where i is the monthly rate and n the number of months.",
    example: "To reach 10,000 in 24 months from 1,000 at 3% a year you would save about 361.83 a month.",
    assumptions: "Assumes a fixed rate and no fees or tax. Real savings rates can change.",
    faqs: [{ q: "What if I have no interest?", a: "Set the rate to 0 and the result is the simple (goal − saved) ÷ months." }],
  },
  {
    slug: "compound-interest-calculator", title: "Compound Interest Calculator",
    description: "See how a balance grows with compound interest and regular monthly contributions.",
    fields: [f("p", "Starting amount", 1000), f("c", "Monthly contribution", 0), f("rate", "Annual interest rate", 5, "%"), f("years", "Years", 10, "years"), f("n", "Compounding periods per year", 1, "")],
    compute: (v) => {
      const per = Math.max(1, Math.round(v.n));
      const b = grow(v.p, v.c, v.rate, v.years, per), dep = v.p + v.c * Math.round(v.years * 12);
      return [m("Final balance", b, true), m("Total you put in", dep), m("Interest earned", b - dep)];
    },
    method: "Monthly growth uses the effective monthly rate (1 + r/n)^(n/12) − 1, with contributions added at the end of each month. With no contributions this equals A = P(1 + r/n)^(nt).",
    example: "1,000 at 5% compounded annually for 10 years grows to about 1,628.89.",
    assumptions: "Fixed rate, no fees, tax or inflation. Investment returns are not guaranteed and can be negative.",
    faqs: [{ q: "What does compounding frequency change?", a: "More frequent compounding gives slightly more interest at the same stated annual rate." }],
  },
  {
    slug: "simple-interest-calculator", title: "Simple Interest Calculator",
    description: "Calculate simple interest and the total amount on a principal over time.",
    fields: [f("p", "Principal", 5000), f("rate", "Annual interest rate", 4, "%"), f("years", "Years", 5, "years")],
    compute: (v) => { const i = (v.p * v.rate * v.years) / 100; return [m("Interest", i, true), m("Total amount", v.p + i)]; },
    method: "Interest = principal × annual rate × years. Interest is never added to the base.",
    example: "5,000 at 4% for 5 years earns 1,000 in interest, for a total of 6,000.",
    assumptions: "Assumes a fixed rate and that interest is not compounded.",
    faqs: [{ q: "How does this differ from compound interest?", a: "Compound interest also earns interest on earlier interest, so it grows faster over time." }],
  },
  {
    slug: "loan-payment-calculator", title: "Loan Payment Calculator",
    description: "Estimate the monthly payment, total cost and interest on a fixed-rate loan.",
    fields: [f("p", "Loan amount", 10000), f("rate", "Annual interest rate", 6, "%"), f("years", "Loan term", 5, "years")],
    compute: (v) => { const p = pmt(v.p, v.rate, v.years), t = p * Math.round(v.years * 12); return [m("Monthly payment", p, true), m("Total repaid", t), m("Total interest", t - v.p)]; },
    method: "Payment = P × i ÷ (1 − (1+i)^−n), where i is the monthly rate (annual rate ÷ 12) and n is the number of monthly payments.",
    example: "10,000 at 6% over 5 years costs about 193.33 a month, with about 1,599.68 total interest.",
    assumptions: "Fixed rate, equal monthly payments, no fees or insurance. Lender quotes may differ.",
    faqs: [{ q: "Why might my lender's figure differ?", a: "Fees, rounding, payment timing and how interest is calculated can all differ by lender and country." }],
  },
  {
    slug: "debt-payoff-calculator", title: "Debt Payoff Calculator",
    description: "See how long a debt takes to clear and how much interest you will pay.",
    fields: [f("b", "Current balance", 5000), f("apr", "Annual interest rate", 18, "%"), f("pay", "Monthly payment", 200)],
    compute: (v) => payoffRows(v.b, v.apr, v.pay),
    method: "Each month interest (balance × annual rate ÷ 12) is added, then your payment is subtracted, until the balance reaches zero.",
    example: "5,000 at 18% with 200 paid monthly takes 32 months.",
    assumptions: "Fixed rate, no new borrowing, and a constant payment. Fees are ignored.",
    faqs: [{ q: "What does “Never” mean?", a: "Your payment is not larger than the monthly interest, so the balance would not fall." }],
  },
  {
    slug: "credit-card-interest-calculator", title: "Credit Card Interest Calculator",
    description: "Estimate the interest on a credit card balance and how long repayment will take.",
    fields: [f("b", "Card balance", 2000), f("apr", "Annual interest rate", 20, "%"), f("pay", "Monthly payment", 100)],
    compute: (v) => [m("Interest charged next month (approx.)", (v.b * v.apr) / 1200), ...payoffRows(v.b, v.apr, v.pay)],
    method: "Monthly interest ≈ balance × annual rate ÷ 12, then repeated as the balance falls. Card issuers may calculate daily, so real figures differ slightly.",
    example: "2,000 at 20% costs roughly 33.33 interest in the first month, and paying 100 a month clears it in 25 months.",
    assumptions: "No new purchases, a fixed rate and no fees. Many cards charge no interest if the full statement balance is paid on time.",
    faqs: [{ q: "Is this my exact interest?", a: "No. It is an estimate, so check your statement for the amount actually charged." }],
  },
  {
    slug: "emergency-fund-calculator", title: "Emergency Fund Calculator",
    description: "Work out a target emergency fund from your essential monthly expenses.",
    fields: [f("e", "Essential monthly expenses", 2000), f("mo", "Months of cover", 6, "months"), f("s", "Current emergency savings", 3000)],
    compute: (v) => { const t = v.e * v.mo; return [m("Target emergency fund", t, true), m("Still to save", Math.max(0, t - v.s)), { label: "Progress", value: t > 0 ? Math.min(100, (v.s / t) * 100) : 0, kind: "pct" }]; },
    method: "Target = essential monthly expenses × months of cover. Shortfall = target − current savings.",
    example: "2,000 of essentials × 6 months gives a 12,000 target; with 3,000 saved you need 9,000 more.",
    assumptions: "Three to six months is a common guideline, not a rule. Essentials include housing, utilities, food, transport and minimum debt payments.",
    faqs: [{ q: "How many months should I choose?", a: "It depends on job stability, dependants and other safety nets, so many people choose more when income is uncertain." }],
  },
  {
    slug: "retirement-savings-calculator", title: "Retirement Savings Calculator",
    description: "Project a retirement pot with regular contributions, shown in future and today's money.",
    fields: [f("age", "Current age", 35, "age"), f("ret", "Retirement age", 65, "age"), f("cur", "Current savings", 10000), f("mo", "Monthly contribution", 300), f("rate", "Expected annual return", 6, "%"), f("inf", "Expected inflation", 2.5, "%")],
    compute: (v) => {
      const y = Math.max(0, v.ret - v.age), b = grow(v.cur, v.mo, v.rate, y, 12), dep = v.cur + v.mo * y * 12;
      return [m("Projected pot (future money)", b, true), m("Same pot in today's money", b / Math.pow(1 + v.inf / 100, y), true), m("Total you contribute", dep)];
    },
    method: "Monthly compounding with contributions at the end of each month. Today's-money value = projected pot ÷ (1 + inflation)^years.",
    example: "35 to 65, 10,000 saved, 300 a month at 6% gives about 361,580, or about 172,381 in today's money at 2.5% inflation.",
    assumptions: "Constant return and inflation, no tax, fees, or changes to contributions. Real returns vary and can be negative, and pension rules differ by country. This is an illustration, not a forecast.",
    faqs: [{ q: "What return should I use?", a: "Nobody can know future returns. Try several rates, including low ones, to see a range of outcomes." }],
  },
  {
    slug: "salary-to-hourly-calculator", title: "Salary to Hourly Calculator",
    description: "Convert an annual salary into an hourly, weekly and monthly equivalent.",
    fields: [f("s", "Annual salary", 52000), f("h", "Hours per week", 40, "hours"), f("w", "Paid weeks per year", 52, "weeks")],
    compute: (v) => { const hrs = v.h * v.w; return [m("Hourly rate", hrs > 0 ? v.s / hrs : 0, true), m("Weekly pay", v.w > 0 ? v.s / v.w : 0), m("Monthly pay", v.s / 12)]; },
    method: "Hourly = salary ÷ (hours per week × paid weeks). Weekly = salary ÷ weeks. Monthly = salary ÷ 12.",
    example: "52,000 ÷ (40 × 52) = 25.00 an hour.",
    assumptions: "Uses gross (pre-tax) pay and ignores unpaid overtime, leave rules and benefits.",
    faqs: [{ q: "Should I use paid weeks or all 52?", a: "Use the weeks you are paid for. Unpaid time off lowers the weeks and raises the effective hourly rate." }],
  },
  {
    slug: "hourly-to-annual-salary-calculator", title: "Hourly to Annual Salary Calculator",
    description: "Convert an hourly wage into annual, monthly and weekly earnings.",
    fields: [f("r", "Hourly rate", 25), f("h", "Hours per week", 40, "hours"), f("w", "Paid weeks per year", 52, "weeks")],
    compute: (v) => { const a = v.r * v.h * v.w; return [m("Annual pay", a, true), m("Monthly pay", a / 12), m("Weekly pay", v.r * v.h)]; },
    method: "Annual = hourly rate × hours per week × paid weeks. Monthly = annual ÷ 12. Weekly = rate × hours.",
    example: "25 × 40 × 52 = 52,000 a year.",
    assumptions: "Gross (pre-tax) pay. Overtime, unpaid leave and irregular hours are not included.",
    faqs: [{ q: "Does this show take-home pay?", a: "No. Tax and deductions vary by country and personal circumstances." }],
  },
  {
    slug: "inflation-calculator", title: "Inflation Calculator",
    description: "See how inflation changes what money can buy over time.",
    fields: [f("a", "Amount today", 100), f("r", "Average annual inflation", 3, "%"), f("y", "Years", 10, "years")],
    compute: (v) => { const g = Math.pow(1 + v.r / 100, v.y); return [m("Future cost of the same goods", v.a * g, true), m("Buying power of the amount in today's terms", v.a / g, true)]; },
    method: "Future cost = amount × (1 + inflation)^years. Buying power = amount ÷ (1 + inflation)^years.",
    example: "At 3% for 10 years, something costing 100 today costs about 134.39, and 100 later buys what about 74.41 buys today.",
    assumptions: "Uses one constant rate. Actual inflation changes yearly and differs by country and by item.",
    faqs: [{ q: "Can I use a negative rate?", a: "Not here. This tool assumes prices rise, so enter 0 or a positive rate." }],
  },
  {
    slug: "mortgage-payment-calculator", title: "Mortgage Payment Calculator",
    description: "Estimate monthly mortgage principal and interest from price, deposit, rate and term.",
    fields: [f("price", "Home price", 300000), f("down", "Deposit / down payment", 60000), f("rate", "Annual interest rate", 6.5, "%"), f("years", "Mortgage term", 30, "years")],
    compute: (v) => { const L = Math.max(0, v.price - v.down), p = pmt(L, v.rate, v.years), t = p * Math.round(v.years * 12); return [m("Amount borrowed", L), m("Monthly payment (principal + interest)", p, true), m("Total interest", t - L)]; },
    method: "Uses the standard amortisation formula: Payment = L × i ÷ (1 − (1+i)^−n), with L the loan, i the monthly rate and n the number of months.",
    example: "Borrowing 240,000 at 6.5% over 30 years is about 1,516.96 a month, with about 306,106.77 total interest.",
    assumptions: "Excludes property tax, insurance, fees and rate changes. Mortgage rules, rate types and quoting conventions differ by country, so check with a lender.",
    faqs: [{ q: "Why is my quote higher?", a: "Quotes usually add taxes, insurance, fees or a different rate or payment schedule." }],
  },
  {
    slug: "net-worth-calculator", title: "Net Worth Calculator",
    description: "Add up assets and debts to find your net worth.",
    fields: [f("cash", "Cash and savings", 15000), f("inv", "Investments and retirement accounts", 25000), f("prop", "Property value", 0), f("oa", "Other assets (vehicles etc.)", 20000), f("mort", "Mortgage balance", 0), f("loan", "Loans", 30000), f("card", "Credit card debt", 5000), f("od", "Other debts", 10000)],
    compute: (v) => { const a = v.cash + v.inv + v.prop + v.oa, l = v.mort + v.loan + v.card + v.od; return [m("Total assets", a), m("Total liabilities", l), m("Net worth", a - l, true)]; },
    method: "Net worth = total assets − total liabilities.",
    example: "Assets of 60,000 and debts of 45,000 give a net worth of 15,000.",
    assumptions: "Asset values such as property and vehicles are estimates. A negative result is common early in life.",
    faqs: [{ q: "How often should I update it?", a: "Every few months or once a year, to see the trend." }],
  },
  {
    slug: "savings-growth-calculator", title: "Savings Growth Calculator",
    description: "Project the growth of savings with regular deposits and monthly interest.",
    fields: [f("p", "Starting balance", 1000), f("c", "Monthly deposit", 100), f("rate", "Annual interest rate", 4, "%"), f("years", "Years", 5, "years")],
    compute: (v) => { const b = grow(v.p, v.c, v.rate, v.years, 12), dep = v.p + v.c * Math.round(v.years * 12); return [m("Balance at the end", b, true), m("Total deposited", dep), m("Interest earned", b - dep), m("Balance after year 1", grow(v.p, v.c, v.rate, 1, 12))]; },
    method: "Interest compounds monthly at rate ÷ 12, with deposits added at the end of each month.",
    example: "1,000 plus 100 a month at 4% for 5 years grows to about 7,850.89, from 7,000 deposited.",
    assumptions: "A fixed rate, no withdrawals, fees or tax. Savings rates often change.",
    faqs: [{ q: "How is this different from the compound interest calculator?", a: "It fixes monthly compounding and also shows the balance after the first year." }],
  },
];

export const getCalc = (slug: string) => CALCS.find((c) => c.slug === slug);

export const ARTICLE_CALCS: Record<string, string[]> = {
  "how-to-create-a-monthly-budget": ["monthly-budget-calculator"],
  "how-to-save-money-simple-ways": ["savings-goal-calculator"],
  "how-much-should-you-save-every-month": ["savings-goal-calculator", "savings-growth-calculator"],
  "what-is-an-emergency-fund": ["emergency-fund-calculator"],
  "how-compound-interest-works": ["compound-interest-calculator"],
  "simple-interest-vs-compound-interest": ["simple-interest-calculator", "compound-interest-calculator"],
  "how-to-pay-off-debt-faster": ["debt-payoff-calculator"],
  "how-credit-cards-work": ["credit-card-interest-calculator"],
  "how-to-calculate-your-net-worth": ["net-worth-calculator"],
  "how-to-save-your-first-1000": ["savings-goal-calculator"],
  "how-inflation-affects-your-money": ["inflation-calculator"],
  "how-to-start-investing-for-beginners": ["retirement-savings-calculator"],
};
