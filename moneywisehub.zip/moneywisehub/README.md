# MoneyWiseHub (Phase 1)

Next.js 15 + TypeScript + Tailwind. Includes layout, SEO (metadata, canonical, sitemap, robots, JSON-LD), 5 articles, disclaimer page, and an AdSense placeholder that stays off until you add a real publisher ID.

## Run
    npm install
    cp .env.example .env.local   # set NEXT_PUBLIC_SITE_URL
    npm run dev

## Deploy (Vercel)
Push to GitHub, import the repo in Vercel, set NEXT_PUBLIC_SITE_URL, then add your custom domain under Project > Domains.

## Phase 2: legal and info pages (done)
About, Contact (working form via Resend), Privacy, Terms, Cookie, Editorial, Authors, Disclaimer, HTML sitemap. Set the env vars in .env.example. The form returns a clear "not configured" error until Resend keys are set.
Have the Privacy, Terms and Cookie pages reviewed by a legal professional for your jurisdiction and business details before relying on them.
Before turning on AdSense, add a cookie consent tool (Google requires a certified CMP for UK/EEA visitors) and update the Cookie Policy.

## Phase 3: 15 calculators (done)
All at /calculators, driven by lib/calculators.ts (pure functions, real-time, currency selector, method/example/assumptions/FAQs).

## Not built yet
articles 16-25 (Needs vs Wants, Savings Plan, Personal Loans, Financial Independence, Hourly Salary, Emergency Budget, Interest Rates, Realistic Goals, Money Mistakes, Manage Monthly Expenses), ads.txt (add after AdSense gives your real publisher ID).
