"use client";
import { useMemo, useState } from "react";
import { getCalc, type Row } from "@/lib/calculators";

const CUR: Record<string, { locale: string; sym: string }> = { USD: { locale: "en-US", sym: "$" }, GBP: { locale: "en-GB", sym: "£" }, CAD: { locale: "en-CA", sym: "$" }, AUD: { locale: "en-AU", sym: "$" } };

export default function CalculatorUI({ slug }: { slug: string }) {
  const calc = getCalc(slug)!;
  const [cur, setCur] = useState("USD");
  const [vals, setVals] = useState<Record<string, string>>(() => Object.fromEntries(calc.fields.map((f) => [f.id, String(f.def)])));
  const parsed = useMemo(() => {
    const out: Record<string, number> = {}; let ok = true;
    for (const f of calc.fields) { const raw = vals[f.id]; const x = raw.trim() === "" ? 0 : Number(raw); if (!Number.isFinite(x) || x < 0) ok = false; out[f.id] = x; }
    return { out, ok };
  }, [vals, calc]);
  const rows: Row[] = parsed.ok ? calc.compute(parsed.out) : [];
  const money = (x: number) => new Intl.NumberFormat(CUR[cur].locale, { style: "currency", currency: cur, maximumFractionDigits: 2 }).format(Number.isFinite(x) ? x : 0);
  const show = (r: Row) => r.kind === "money" ? money(r.value as number) : r.kind === "pct" ? `${(r.value as number).toFixed(1)}%` : r.kind === "num" ? String(r.value) : String(r.value);
  const suffix: Record<string, string> = { "%": "%", years: "yrs", months: "mo", hours: "hrs", weeks: "wks" };

  return (
    <div className="rounded-2xl border border-slate-200 p-5">
      <div className="mb-4 flex items-center gap-3">
        <label htmlFor="cur" className="text-sm font-medium">Currency</label>
        <select id="cur" value={cur} onChange={(e) => setCur(e.target.value)} className="rounded-lg border border-slate-300 px-2 py-1">
          {Object.keys(CUR).map((c) => <option key={c}>{c}</option>)}
        </select>
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        {calc.fields.map((f) => (
          <div key={f.id}>
            <label htmlFor={f.id} className="text-sm font-medium">{f.label}</label>
            <div className="mt-1 flex items-center rounded-lg border border-slate-300 focus-within:border-brand">
              {f.unit === "money" && <span className="pl-3 text-slate-500">{CUR[cur].sym}</span>}
              <input id={f.id} inputMode="decimal" value={vals[f.id]} onChange={(e) => setVals({ ...vals, [f.id]: e.target.value })} className="w-full rounded-lg bg-transparent px-3 py-2 outline-none" />
              {suffix[f.unit] && <span className="pr-3 text-sm text-slate-500">{suffix[f.unit]}</span>}
            </div>
          </div>
        ))}
      </div>
      <div aria-live="polite" className="mt-6 rounded-xl bg-brand-soft p-4">
        {!parsed.ok ? <p className="text-red-700">Please enter valid numbers of zero or more.</p> : (
          <dl className="space-y-2">
            {rows.map((r) => (
              <div key={r.label} className="flex flex-wrap justify-between gap-2">
                <dt className="text-slate-600">{r.label}</dt>
                <dd className={r.big ? "text-xl font-bold text-brand-dark" : "font-semibold"}>{show(r)}</dd>
              </div>
            ))}
          </dl>
        )}
      </div>
    </div>
  );
}
