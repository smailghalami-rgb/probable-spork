"use client";
import { useState } from "react";
export default function ContactForm() {
  const [status, setStatus] = useState<"idle" | "sending" | "ok" | "error">("idle");
  const [msg, setMsg] = useState("");
  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setStatus("sending");
    const fd = new FormData(e.currentTarget);
    try {
      const res = await fetch("/api/contact", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(Object.fromEntries(fd)) });
      const data = await res.json();
      if (res.ok) { setStatus("ok"); setMsg("Thanks, your message has been sent."); (e.target as HTMLFormElement).reset(); }
      else { setStatus("error"); setMsg(data.error ?? "Something went wrong. Please try again."); }
    } catch { setStatus("error"); setMsg("Network error. Please try again."); }
  }
  const field = "mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 focus:border-brand focus:outline-none";
  return (
    <form onSubmit={onSubmit} className="space-y-4" noValidate>
      <div><label htmlFor="name" className="font-medium">Name</label><input id="name" name="name" required maxLength={100} className={field} /></div>
      <div><label htmlFor="email" className="font-medium">Email</label><input id="email" name="email" type="email" required maxLength={200} className={field} /></div>
      <div><label htmlFor="message" className="font-medium">Message</label><textarea id="message" name="message" required minLength={10} maxLength={2000} rows={6} className={field} /></div>
      <div aria-hidden className="hidden"><label>Leave blank<input name="website" tabIndex={-1} autoComplete="off" /></label></div>
      <button disabled={status === "sending"} className="rounded-lg bg-brand px-5 py-3 font-semibold text-white hover:bg-brand-dark disabled:opacity-60">{status === "sending" ? "Sending…" : "Send message"}</button>
      {status !== "idle" && status !== "sending" && <p role="status" className={status === "ok" ? "text-green-700" : "text-red-700"}>{msg}</p>}
    </form>
  );
}
