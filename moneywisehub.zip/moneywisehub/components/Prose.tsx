import Breadcrumbs from "@/components/Breadcrumbs";
import { UPDATED } from "@/lib/site";
export default function Prose({ title, updated = true, children }: { title: string; updated?: boolean; children: React.ReactNode }) {
  return (
    <div className="mx-auto max-w-3xl">
      <Breadcrumbs items={[{ name: "Home", href: "/" }, { name: title }]} />
      <h1 className="text-3xl font-bold text-slate-900">{title}</h1>
      {updated && <p className="mt-2 text-sm text-slate-500">Last updated: {UPDATED}</p>}
      <div className="mt-6 space-y-4 leading-relaxed [&_h2]:mt-8 [&_h2]:text-xl [&_h2]:font-bold [&_h2]:text-slate-900 [&_ul]:list-disc [&_ul]:space-y-2 [&_ul]:pl-6 [&_a]:text-brand [&_a]:underline">
        {children}
      </div>
    </div>
  );
}
