import Link from "next/link";
import { SITE } from "@/lib/site";
const LINKS = [
  ["/blog", "Articles"], ["/calculators", "Calculators"], ["/about", "About Us"], ["/authors", "Authors"], ["/editorial-policy", "Editorial Policy"],
  ["/contact", "Contact Us"], ["/privacy-policy", "Privacy Policy"], ["/terms", "Terms & Conditions"],
  ["/cookie-policy", "Cookie Policy"], ["/disclaimer", "Disclaimer"], ["/sitemap", "Sitemap"],
];
export default function Footer() {
  return (
    <footer className="mt-16 border-t border-slate-200 bg-slate-50">
      <div className="mx-auto max-w-5xl px-4 py-8 text-sm text-slate-600">
        <nav aria-label="Footer" className="mb-4 flex flex-wrap gap-x-5 gap-y-2 font-medium">
          {LINKS.map(([href, label]) => <Link key={href} href={href} className="hover:text-brand">{label}</Link>)}
        </nav>
        <p>{SITE.name} provides general financial education only. It is not financial, investment, tax or legal advice. Always consider your own circumstances and speak to a qualified professional.</p>
        <p className="mt-2">© {new Date().getFullYear()} {SITE.name}</p>
      </div>
    </footer>
  );
}
