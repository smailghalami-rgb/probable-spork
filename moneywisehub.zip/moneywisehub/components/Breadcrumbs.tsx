import Link from "next/link";
export default function Breadcrumbs({ items }: { items: { name: string; href?: string }[] }) {
  return (
    <nav aria-label="Breadcrumb" className="mb-4 text-sm text-slate-500">
      <ol className="flex flex-wrap gap-2">
        {items.map((it, i) => (
          <li key={it.name} className="flex gap-2">
            {it.href ? <Link href={it.href} className="hover:text-brand">{it.name}</Link> : <span>{it.name}</span>}
            {i < items.length - 1 && <span aria-hidden>/</span>}
          </li>
        ))}
      </ol>
    </nav>
  );
}
