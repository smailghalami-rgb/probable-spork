// Renders nothing until a real AdSense publisher ID is set in NEXT_PUBLIC_ADSENSE_CLIENT.
// Keep slots away from links/buttons to avoid accidental clicks, and add the real ad unit code from AdSense.
export default function AdSlot({ label = "Advertisement" }: { label?: string }) {
  if (!process.env.NEXT_PUBLIC_ADSENSE_CLIENT) return null;
  return (
    <aside aria-label={label} className="my-8 min-h-[120px] rounded border border-dashed border-slate-300 p-2 text-center text-xs text-slate-400">
      {label}
      {/* Paste your AdSense <ins className="adsbygoogle" ...> unit here once approved. */}
    </aside>
  );
}
