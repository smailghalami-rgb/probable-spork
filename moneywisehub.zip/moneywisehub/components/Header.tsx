import Link from "next/link";
import { SITE } from "@/lib/site";
export default function Header() {
  return (
    <header className="border-b border-slate-200 bg-white">
      <div className="mx-auto flex max-w-5xl items-center justify-between px-4 py-4">
        <Link href="/" className="text-xl font-bold text-brand">{SITE.name}</Link>
        <nav aria-label="Main" className="flex gap-5 text-sm font-medium">
          <Link href="/" className="hover:text-brand">Home</Link>
          <Link href="/calculators" className="hover:text-brand">Calculators</Link>
          <Link href="/blog" className="hover:text-brand">Articles</Link>
        </nav>
      </div>
    </header>
  );
}
